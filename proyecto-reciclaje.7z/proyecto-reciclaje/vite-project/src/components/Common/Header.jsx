import React from 'react';
import { Link } from 'react-router-dom';
import { FaRecycle } from 'react-icons/fa';

const Header = () => {
  
  const isAuthenticated = false; 
  const isAdmin = false; 

  return (
    <header style={{
      backgroundColor: '#24292f', 
      padding: '10px 20px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    }}>
      <Link to="/" style={{ color: 'white', display: 'flex', alignItems: 'center', fontSize: '20px', fontWeight: 'bold' }}>
        <FaRecycle size={24} style={{ marginRight: '10px' }} />
        Reciclaje Popayán
      </Link>

      <nav>

        {!isAuthenticated && (
          <div style={{ display: 'flex', gap: '10px' }}>
            <Link to="/login" className="github-button secondary">
              Iniciar Sesión
            </Link>
            <Link to="/register" className="github-button primary">
              Registrarse
            </Link>
          </div>
        )}
      </nav>
    </header>
  );
}

export default Header;