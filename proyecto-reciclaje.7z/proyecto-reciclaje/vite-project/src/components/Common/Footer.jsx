import React from 'react';

const Footer = () => {
  return (
    <footer style={{
      
      backgroundColor: 'var(--gh-bg-color)', 
      borderTop: '1px solid var(--gh-border-color)', 
      padding: '20px',
      textAlign: 'center',
      color: '#57606a', 
      fontSize: '13px'
    }}>
      © 2025 Proyecto Reciclaje Popayán. Todos los derechos reservados.
    </footer>
  );
};

export default Footer;