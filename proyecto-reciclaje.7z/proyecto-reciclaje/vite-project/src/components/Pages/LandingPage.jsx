import React from 'react';
import { Link } from 'react-router-dom';

const LandingPage = () => {
  return (
    <div style={{ 
        textAlign: 'center', 
        padding: '100px 20px', 
        minHeight: 'calc(100vh - 120px)' 
    }}>
        <h1 style={{ 
            fontSize: '36px', 
            marginBottom: '20px', 
            color: 'var(--gh-text-color)' 
        }}>
          Tablero y Control Punto De Reciclaje
        </h1>
        
        <p style={{ 
            fontSize: '18px', 
            marginBottom: '50px', 
            color: '#6a737d' 
        }}>
          Bienvenido. Utiliza esta plataforma para gestionar o registrar tu punto de reciclaje en Popayán.
        </p>
        
        <div style={{ display: 'flex', justifyContent: 'center', gap: '20px' }}>
          
          <Link 
            to="/login" 
            className="github-button secondary" 
            style={{ padding: '12px 30px', fontSize: '16px' }}
          >
            Iniciar Sesión
          </Link>
          
          <Link 
            to="/register" 
            className="github-button primary" 
            style={{ padding: '12px 30px', fontSize: '16px' }}
          >
            Registrarse
          </Link>
        </div>
    </div>
  );
};

export default LandingPage;