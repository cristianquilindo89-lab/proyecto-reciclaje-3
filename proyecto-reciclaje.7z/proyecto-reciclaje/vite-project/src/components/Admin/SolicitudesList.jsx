import React, { useState, useEffect } from 'react';
import { FaCheckCircle, FaTimesCircle, FaMapMarkerAlt, FaFilter, FaSearch, FaClock, FaInbox } from 'react-icons/fa';

const mockSolicitudes = [
  { 
    id: 1, 
    nombre: 'Punto Ecológico Central', 
    direccion: 'Carrera 7 # 12-50, Centro', 
    barrio: 'Centro', 
    fechaCreacion: '2025-11-01', 
    proponente: 'Juan Pérez',
    materiales: ['Plástico', 'Papel', 'Cartón'],
    estado: 'Pendiente'
  },
  { 
    id: 2, 
    nombre: 'Recicla Fácil Norte', 
    direccion: 'Calle 100 # 3N-20, B/Norte', 
    barrio: 'Norte', 
    fechaCreacion: '2025-11-05', 
    proponente: 'Asoc. Recicladores',
    materiales: ['Vidrio', 'Metal'],
    estado: 'Pendiente'
  },
  { 
    id: 3, 
    nombre: 'Eco-Park Móvil', 
    direccion: 'Parque Caldas', 
    barrio: 'Centro Histórico', 
    fechaCreacion: '2025-11-10', 
    proponente: 'Alcaldía',
    materiales: ['Plástico', 'Vidrio', 'Cartón', 'Pilas'],
    estado: 'Pendiente'
  }
];

const SolicitudCard = ({ solicitud, onAction }) => {
  return (
    <div style={cardStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
        <h4 style={{ margin: 0, color: 'var(--gh-link-color)' }}>{solicitud.nombre}</h4>
        <span style={badgeStyle}>Pendiente</span>
      </div>
      
      <p style={detailTextStyle}>
        <FaMapMarkerAlt style={{ marginRight: '5px' }} />
        **Dirección:** {solicitud.direccion} ({solicitud.barrio})
      </p>
      
      <p style={detailTextStyle}>
        <FaClock style={{ marginRight: '5px' }} />
        **Solicitado:** {solicitud.fechaCreacion} por {solicitud.proponente}
      </p>

      <div style={materialContainerStyle}>
        **Materiales aceptados:** {solicitud.materiales.join(', ')}
      </div>

      <div style={{ display: 'flex', gap: '10px', marginTop: '15px', justifyContent: 'flex-end' }}>
        
        <button 
          className="github-button primary" 
          onClick={() => onAction(solicitud.id, 'Aprobado')}
        >
          <FaCheckCircle style={{ marginRight: '5px' }} /> Aprobar
        </button>
        
        <button 
          className="github-button danger" 
          onClick={() => onAction(solicitud.id, 'Rechazado')}
        >
          <FaTimesCircle style={{ marginRight: '5px' }} /> Rechazar
        </button>

        <button 
          className="github-button secondary" 
          onClick={() => alert(`Ver detalles del punto ${solicitud.id} (Redirigir a Mockup 11)`)}
        >
          Ver Detalle
        </button>
      </div>
    </div>
  );
};

const SolicitudesList = () => {
  const [solicitudes, setSolicitudes] = useState(mockSolicitudes);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBarrio, setFilterBarrio] = useState('Todos');

  useEffect(() => {
  }, []);

  const handleAction = (id, newStatus) => {

    console.log(`Punto ID ${id} marcado como: ${newStatus}`);

    setSolicitudes(solicitudes.filter(s => s.id !== id));
    
    alert(`Solicitud ID ${id} ha sido ${newStatus}. Base de datos actualizada.`);
  };

  const filteredSolicitudes = solicitudes.filter(solicitud => {
    const matchesSearch = solicitud.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          solicitud.direccion.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesBarrio = filterBarrio === 'Todos' || solicitud.barrio === filterBarrio;
    
    return matchesSearch && matchesBarrio;
  });

  const uniqueBarrios = ['Todos', ...new Set(mockSolicitudes.map(s => s.barrio))];

  return (
    <div>
      <h1 style={{ borderBottom: '1px solid var(--gh-border-color)', paddingBottom: '10px' }}>
        <FaInbox style={{ marginRight: '10px' }} /> Solicitudes Pendientes ({filteredSolicitudes.length})
      </h1>

      <div style={filterBarContainerStyle}>
        
        <div style={{ position: 'relative', flexGrow: 1 }}>
          <input 
            type="text" 
            placeholder="Buscar por nombre o dirección..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="github-input" 
            style={{ width: '100%', paddingLeft: '35px', marginBottom: 0 }}
          />
          <FaSearch style={searchIconStyle} />
        </div>
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <FaFilter color="#57606a" />
          <select 
            className="github-input" 
            value={filterBarrio}
            onChange={(e) => setFilterBarrio(e.target.value)}
            style={{ marginBottom: 0, width: '150px' }}
          >
            {uniqueBarrios.map(barrio => (
              <option key={barrio} value={barrio}>{barrio}</option>
            ))}
          </select>
        </div>
      </div>

      <div style={gridContainerStyle}>
        {filteredSolicitudes.length > 0 ? (
          filteredSolicitudes.map(solicitud => (
            <SolicitudCard 
              key={solicitud.id} 
              solicitud={solicitud} 
              onAction={handleAction} 
            />
          ))
        ) : (
          <p style={{ gridColumn: '1 / -1', textAlign: 'center', color: '#6a737d' }}>
            🎉 ¡Todas las solicitudes han sido procesadas!
          </p>
        )}
      </div>
    </div>
  );
};

export default SolicitudesList;

const cardStyle = {
  backgroundColor: 'white',
  border: '1px solid var(--gh-border-color)',
  borderRadius: '6px',
  padding: '15px',
  boxShadow: '0 1px 3px rgba(27, 31, 36, 0.08)'
};

const badgeStyle = {
  backgroundColor: '#f1e05a', 
  color: '#6e4016', 
  padding: '3px 8px',
  borderRadius: '20px',
  fontSize: '12px',
  fontWeight: '600'
};

const detailTextStyle = {
  fontSize: '14px',
  color: '#57606a',
  margin: '5px 0'
};

const materialContainerStyle = {
  fontSize: '13px',
  color: 'var(--gh-text-color)',
  borderTop: '1px dashed var(--gh-border-color)',
  paddingTop: '10px',
  marginTop: '10px'
};

const filterBarContainerStyle = {
  display: 'flex',
  gap: '20px',
  marginBottom: '20px',
  padding: '15px 0',
  borderBottom: '1px solid var(--gh-border-color)'
};

const searchIconStyle = {
    position: 'absolute',
    left: '10px',
    top: '50%',
    transform: 'translateY(-50%)',
    color: '#6a737d'
};

const gridContainerStyle = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
  gap: '20px',
  marginTop: '20px'
};