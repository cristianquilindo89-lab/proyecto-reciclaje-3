import React from 'react';
import { NavLink } from 'react-router-dom';
import { FaInbox, FaMapMarkerAlt, FaFlask, FaGift } from 'react-icons/fa';

const AdminSidebar = () => {
  return (
    <nav className="admin-sidebar"> 
      <h3 style={{ padding: '0 20px', margin: '0 0 15px 0', fontSize: '18px', color: 'var(--gh-text-color)' }}>
        Administración
      </h3>
      <div className="admin-sidebar-menu">
        
        <NavLink 
          to="/admin" 
          end 
          className={({ isActive }) => isActive ? 'active' : ''}
        >
            <FaInbox style={{ marginRight: '10px' }} /> Solicitudes Pendientes
        </NavLink>
        
        <NavLink 
          to="/admin/puntos" 
          className={({ isActive }) => isActive ? 'active' : ''}
        >
            <FaMapMarkerAlt style={{ marginRight: '10px' }} /> Puntos Activos
        </NavLink>
        
        <NavLink 
          to="/admin/materiales" 
          className={({ isActive }) => isActive ? 'active' : ''}
        >
            <FaFlask style={{ marginRight: '10px' }} /> Gestión de Materiales
        </NavLink>
        
        <NavLink 
          to="/admin/beneficios" 
          className={({ isActive }) => isActive ? 'active' : ''}
        >
            <FaGift style={{ marginRight: '10px' }} /> Canjes y Beneficios
        </NavLink>
      </div>
    </nav>
  );
};

export default AdminSidebar;