import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaRecycle } from 'react-icons/fa'; 

const Register = () => {
  
  const [formData, setFormData] = useState({
    nombre: '',
    apellido: '',
    email: '',
    password: '',
    barrio_comuna: ''
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    
    console.log('Datos a registrar:', formData);
    
    alert('Usuario registrado exitosamente. Por favor, inicia sesión.');

  };

  return (

    <div className="layout-register">
        
        <div className="register-image-panel">
            
        </div>

        <div className="register-form-panel">
            <FaRecycle size={32} color="#2da44e" style={{ marginBottom: '10px' }} />
            
            <h1 style={{ fontSize: '24px', fontWeight: '300', marginBottom: '16px' }}>
                Únete a la iniciativa de reciclaje de Popayán
            </h1>

            <form onSubmit={handleSubmit} className="github-form-container" style={{maxWidth: '400px'}}>
                
                <div style={{ display: 'flex', gap: '10px' }}>
                    <div style={{ flex: 1 }}>
                        <label className="github-input-label">Nombre</label>
                        <input type="text" name="nombre" className="github-input" onChange={handleChange} required />
                    </div>
                    <div style={{ flex: 1 }}>
                        <label className="github-input-label">Apellido</label>
                        <input type="text" name="apellido" className="github-input" onChange={handleChange} required />
                    </div>
                </div>
                
                <label className="github-input-label">Email</label>
                <input type="email" name="email" className="github-input" onChange={handleChange} required />
                
                <label className="github-input-label">Contraseña</label>
                <input type="password" name="password" className="github-input" onChange={handleChange} required />
                
                <label className="github-input-label">Barrio/Comuna</label>
                <input type="text" name="barrio_comuna" className="github-input" onChange={handleChange} />

                <button 
                  type="submit" 
                  className="github-button primary" 
                  style={{ width: '100%', marginTop: '10px' }}
                >
                    Registrar mi cuenta
                </button>
            </form>

            <p style={{ marginTop: '20px' }}>
                ¿Ya tienes una cuenta? <Link to="/login" style={{ color: 'var(--gh-link-color)' }}>Inicia Sesión</Link>
            </p>
        </div>
    </div>
  );
};

export default Register;