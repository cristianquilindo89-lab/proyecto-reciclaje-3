import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaRecycle } from 'react-icons/fa'; 

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const userRole = (email === 'admin@mail.com' && password === '1234') ? 'Admin' : 'Ciudadano';

    if (userRole === 'Admin') {
    
        navigate('/admin');
    } else if (userRole === 'Ciudadano') {

        alert('Simulación: Iniciando sesión como Ciudadano. No hay dashboard definido aún.');

    } else {
        alert('Credenciales incorrectas. Intenta de nuevo.');
    }
  };

  return (
    
    <div className="auth-center-layout"> 
        <FaRecycle size={32} color="#2da44e" style={{ marginBottom: '20px' }} />
        
        <h1 style={{ fontSize: '24px', fontWeight: '300', marginBottom: '16px' }}>
            Inicia sesión en Reciclaje Popayán
        </h1>

        <form onSubmit={handleSubmit} className="github-form-container">
            <label className="github-input-label">Email</label>
            <input 
              type="email" 
              className="github-input" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              required 
            />
            
            <label className="github-input-label">Contraseña</label>
            <input 
              type="password" 
              className="github-input" 
              value={password} 
              onChange={(e) => setPassword(e.target.value)} 
              required 
            />

            <button 
              type="submit" 
              className="github-button primary" 
              style={{ width: '100%' }}
            >
                Iniciar Sesión
            </button>
        </form>

        <p style={{ marginTop: '20px' }}>
            ¿Nuevo aquí? <Link to="/register" style={{ color: 'var(--gh-link-color)' }}>Crea una cuenta.</Link>
        </p>
    </div>
  );
};

export default Login;