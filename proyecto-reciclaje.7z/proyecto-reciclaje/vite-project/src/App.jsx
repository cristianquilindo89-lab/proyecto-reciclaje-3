import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Header from "./components/Header.jsx";

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
       <Header />
        <main style ={{ padding: '20px'}}>
           <h2>Clasifica tus Residuos</h2>
           <h1>¡Bienvenido a mi Aplicación de Reciclaje!</h1>
           <p>Aquí irá el contenido principal de mi app.</p>
           <p>Pronto tendremos más componentes aquí...</p>
        </main>
    </>
  )
}

export default App;
